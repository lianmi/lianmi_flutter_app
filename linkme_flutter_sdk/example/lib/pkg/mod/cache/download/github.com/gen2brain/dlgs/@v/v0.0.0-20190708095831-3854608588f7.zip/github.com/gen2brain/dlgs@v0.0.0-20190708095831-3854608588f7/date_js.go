// +build js

package dlgs

import (
//"github.com/gopherjs/gopherjs/js"
)

// Date displays a calendar dialog, returning the date and a bool for success.
func Date(title, text string, defaultDate time.Time) (time.Time, bool, error) {
	return nil, false, ErrNotImplemented
}
