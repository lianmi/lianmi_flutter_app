// Package flutter combines the embedder API with GLFW and plugins. Flutter and
// Go on the desktop.
//
// go-flutter is in active development. API's must be considered alpha/unstable
// and may be changed at any time.
package flutter
